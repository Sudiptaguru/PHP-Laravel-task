<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PartnerController;
use App\Http\Controllers\ApiKeyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

//Partner
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::view('user','partner_datatable');

// Route::resource('partner',PartnerController::class);

Route::get('partner', [PartnerController::class, 'partnerlist'])->name('partner.partnerlist');

Route::get('add_partner', [PartnerController::class, 'addpartner'])->name('partner.addpartner');

Route::post('savepartner', [PartnerController::class, 'savepartner'])->name('partner.savepartner');

Route::get('edit_partner/{id}', [PartnerController::class, 'editpartner'])->name('partner.editpartner');

Route::post('update_partner', [PartnerController::class, 'updatepartner'])->name('partner.updatepartner');

Route::get('delete_partner/{id}', [PartnerController::class, 'deletepartner'])->name('partner.deletepartner');



/* API KEY Master */

Route::get('apikey', [ApiKeyController::class, 'index'])->name('apikey.list');

Route::get('add_apikey', [ApiKeyController::class, 'add'])->name('apikey.add');

Route::get('edit_apikey/{id}', [ApiKeyController::class, 'edit'])->name('apikey.edit');

Route::post('save_apikey', [ApiKeyController::class, 'save'])->name('apikey.save');

Route::post('update_apikey', [ApiKeyController::class, 'update'])->name('apikey.update');


Route::get('api', [ApiKeyController::class, 'apilist'])->name('apikey.apilist');

Route::get('add_api', [ApiKeyController::class, 'addapi'])->name('apikey.addapi');

Route::get('edit_api/{id}', [ApiKeyController::class, 'editapi'])->name('apikey.editapi');

Route::post('save_api', [ApiKeyController::class, 'saveapi'])->name('apikey.saveapi');

Route::post('update_api', [ApiKeyController::class, 'updateapi'])->name('apikey.updateapi');
