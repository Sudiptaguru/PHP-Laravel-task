<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class PartnerUserMapping extends Model
{
    protected $connection = 'mysql';

    protected $table = "partner_user_mapping";
    
    protected $fillable = [
        'partner_user_id', 'partner_id', 'user_id', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}