<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ApiKeyMaster extends Model
{
    protected $connection = 'mysql';

    protected $table = "api_key_master";
    
    protected $fillable = [
        'api_key_id', 'api_id', 'ip_add', 'secret_id', 'secret_key', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}