<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AuroPartnerMaster extends Model
{
    protected $connection = 'mysql';

    protected $table = "user_master";
    
    protected $fillable = [
        'user_id', 'user_type_id', 'user_name', 'password', 'role_id', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}