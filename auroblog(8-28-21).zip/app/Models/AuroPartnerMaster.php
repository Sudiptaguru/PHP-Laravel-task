<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AuroPartnerMaster extends Model
{
    protected $connection = 'mysql';

    protected $table = "auro_partner_master";
    
    protected $fillable = [
        'partner_id', 'partner_name', 'partner_source', 'registration_date', 'feature', 'status', 'partner_logo', 'partner_website', 'partner_internal_url', 'required_params', 'mobile_no_verified', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}