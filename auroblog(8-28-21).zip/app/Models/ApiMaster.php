<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ApiMaster extends Model
{
    protected $connection = 'mysql';

    protected $table = "api_master";
    
    protected $fillable = [
        'api_id', 'api_name', 'api_url', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}