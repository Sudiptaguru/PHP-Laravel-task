<!DOCTYPE html>
<html>

@include('header')

<body class="theme-red">
    <!-- Page Loader -->
    @include('loader')

    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>

    <!-- #Float icon -->
    @include('floaticon')

    <!-- Search  -->
    @include('search-bar')

    <!-- Top Bar -->
    @include('navbar')

   @include('leftsidebar')

   @include('rightsidebar')