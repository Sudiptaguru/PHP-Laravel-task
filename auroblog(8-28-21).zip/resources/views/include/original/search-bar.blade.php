<div class="search-bar">
        <div class="search-icon"> <i class="zmdi zmdi-search"></i> </div>
        <input type="text" placeholder="Search...">
        <div class="close-search"> <i class="zmdi zmdi-close"></i> </div>
    </div>