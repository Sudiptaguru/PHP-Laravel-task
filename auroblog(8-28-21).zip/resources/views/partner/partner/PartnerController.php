<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserMaster;
use App\Models\AuroPartnerMaster;
use App\Models\PartnerUserMapping;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

require (__DIR__.'/../../helper.php');

class PartnerController extends Controller{

    /**
     * Create a new controller instance.
     * Kohin Maji     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }

   
    
    
    public function partnerlist(Request $request){
        //$api_result = ApiMaster::get(array('api_id', 'api_name', 'api_url', 'status', 'created_at'))->toArray();
        
        
        $set_limit=10;
        $set_page=1;

        $filePath =  array("set_limit" => $set_limit, "set_page" => $set_page);
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://staging.auroscholar.org/apis/partner/partner_list.php",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30000,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($filePath),
        CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
        ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if($err){
            echo "cURL Error #:" . $err;
        }
        else{
            $result = json_decode($response, true);
            // $api_result=$result['data'];
            // print_r($result); 
            return view('partner.partnerlist', ['result'=>$result]);        
        }   
        
        
        // return view('partner.partnerlist',compact('api_result'));
    }
    
    public function addpartner(){
        return view('partner.addpartner');
    }

     public function savepartner(Request $request){
        $post_data = $request->toArray();

        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->partner_id)){ // redirect if already exist
            return redirect()->route('partner.addpartner')
             ->with('error','Partner Combination already exist');
        }
        $request->validate([
            'partner_name' => 'required',
            'partner_website' => 'required',
            'partner_internal_url' => 'required',
            'partner_source' => 'required',
            'registration_date' => 'required',
            'required_params' => 'required'
        ]);
        $auro_partner_master = [];
        $auro_partner_master['partner_name'] = $post_data['partner_name'];
        $auro_partner_master['partner_source'] = $post_data['partner_source'];
        $auro_partner_master['registration_date'] = $post_data['registration_date'];
        $auro_partner_master['partner_logo'] = $post_data['partner_logo'];
        $auro_partner_master['partner_website'] = $post_data['partner_website'];
        $auro_partner_master['partner_internal_url'] = $post_data['partner_internal_url'];
        $auro_partner_master['required_params'] = $post_data['required_params'];
        $auro_partner_master['created_at'] = date('Y-m-d H:i:s');
        $auro_partner_master['updated_at'] = date('Y-m-d H:i:s');
        $auro_partner_master['user_type_id'] = 3;
        $auro_partner_master['role_id'] = 1;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://staging.auroscholar.org/apis/partner/partner_insert.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            }
            else{
                return redirect()->route('partner.addpartner')->with('message', $resp->message);
            }
        }

        // AuroPartnerMaster::create($auro_partner_master);

        // return redirect()->route('partner.partnerlist')->with('message','Partner added succesfully');
    }

    public function editpartner($id){
        
        $filePath =  array("partner_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://staging.auroscholar.org/apis/partner/partner_view.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
            if($resp->response_code===200){
                $partner_data = $resp->data;
                return view('partner.editpartner',compact('partner_data'));
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            }
            else{
                return redirect()->route('partner.addpartner')->with('message', $resp->message);
            }
        }  
    }

    public function updatepartner(Request $request){
        $post_data = $request->toArray();
        // return $post_data;
        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->partner_id)){ // redirect if already exist
            return redirect()->route('partner.editpartner',$post_data['partner_id'])->with('error','Partner Combination already exist');
        }

        $request->validate([
            'partner_name' => 'required',
            'partner_website' => 'required',
            'partner_internal_url' => 'required'
        ]);
        
        $auro_partner_master = [];
        $auro_partner_master['partner_id'] = $post_data['partner_id'];
        $auro_partner_master['partner_name'] = $post_data['partner_name'];
        $auro_partner_master['partner_source'] = $post_data['partner_source'];
        $auro_partner_master['partner_logo'] = $post_data['partner_logo'];
        $auro_partner_master['partner_website'] = $post_data['partner_website'];
        $auro_partner_master['partner_internal_url'] = $post_data['partner_internal_url'];
        $auro_partner_master['required_params'] = $post_data['required_params'];
        $auro_partner_master['updated_at'] = date('Y-m-d H:i:s');

        // return $auro_partner_master['required_params'];die;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://staging.auroscholar.org/apis/partner/partner_update.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($auro_partner_master),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));die;
            $resp = json_decode($response);
            if($resp->response_code===200){
                return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            }
            else{
                return redirect()->route('partner.editpartner')->with('message', $resp->message);
            }
        }
        // ApiKeyMaster::where('user_id',$post_data['user_id'])->update($auro_partner_master);
        // return redirect()->route('partner.partnerlist')->with('message','Partner updated succesfully');
    }

    public function deletepartner($id){
        
        $filePath =  array("partner_id" => $id);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://staging.auroscholar.org/apis/partner/partner_delete.php",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30000,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($filePath),
            CURLOPT_HTTPHEADER => array(
        // Set here requred headers
        "content-type: application/json",
        "Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
        "Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
        "Lang-Code: english"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } 
        else {
            // print_r(json_decode($response));
            $resp = json_decode($response);
                return redirect()->route('partner.partnerlist')->with('message', $resp->message);
                // return redirect()->route('partner.partnerlist')->with('message', $resp->message);
            
        }
            
    }

   
}