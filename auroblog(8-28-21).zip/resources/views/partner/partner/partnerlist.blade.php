@include('upperpart')

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">Partner List</li>
                    </ul>
                </div>
            </div>
        </div>
        @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
        @endif
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Partner List </h2>
                    </div>
                    <div class="body">
                        <div class="add-button text-right">
                            <a href="{{ route('partner.addpartner') }}"><button type="button" class="btn btn-raised btn-primary waves-effect">Add Partner</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>Partner Name</th>
                                        <th>Partner Logo</th>
                                        <th>Partner Website</th>
                                        <th>Partner Internal URL</th>
                                        <th>Required Params</th>
                                        <th>Partner Source</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    @foreach($result['data'] as $partner)
                                    <tr>
                                        <td>{{ $partner['partner_name'] }}</td>
                                        <td>{{ $partner['partner_logo'] }}</td>
                                        <td>{{ $partner['partner_website'] }}</td>
                                        <td>{{ $partner['partner_internal_url'] }}</td>
                                        <td>{{ $partner['required_params'] }}</td>
                                        <td>{{ $partner['partner_source'] }}</td>
                                        <td><a class="demo-google-material-icon" href="{{ url('edit_partner').'/'.$partner['partner_id'] }}"><i class="material-icons" title="Edit">edit</i></a>|
                                            <a class="demo-google-material-icon" href="{{ url('delete_partner').'/'.$partner['partner_id'] }}" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fa fa-trash-o" style="font-size:24px"></i></a>
                                        </td>
                                    </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@include('lowerpart')
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">