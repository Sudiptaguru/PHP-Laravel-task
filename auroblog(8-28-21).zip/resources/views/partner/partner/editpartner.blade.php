@include('upperpart')
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="">Partner </a></li>
                        <li class="breadcrumb-item active">Edit Partner </li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif
                                                  
        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></but>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
        
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>Edit PARTNER </h2>
                    </div>

                    <div class="body">
                        <form id="form_validation" action="{{ route('partner.updatepartner') }}" method="POST">
                            @csrf
                            <input type="hidden" id="partner_id" name="partner_id" value="{{ @$partner_data->partner_id }}" />
                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Name</b> </p>
                                    <input type="text" class="form-control" name="partner_name" value= "{{ @$partner_data->partner_name }}">
                            </div>
                            @error('partner_name')
                              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                            @enderror

                             <div class="form-group">
                                <p class="m-t-10"> <b>Required Params</b> </p>
                                    <input type="text" class="form-control" name="required_params" value= "{{ @$partner_data->required_params }}">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Internal URL</b> </p>
                                    <input type="text" class="form-control" name="partner_internal_url" value= "{{ @$partner_data->partner_internal_url }}">
                            </div>
                            @error('partner_internal_url')
                              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                            @enderror

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Source</b> </p>
                                    <input type="text" class="form-control" name="partner_source" value= "{{ @$partner_data->partner_source }}">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Logo</b> </p>
                                    <input type="text" class="form-control" name="partner_logo" value= "{{ @$partner_data->partner_logo }}">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Website</b> </p>
                                    <input type="text" class="form-control" name="partner_website" value= "{{ @$partner_data->partner_website }}">
                            </div>
                            @error('partner_website')
                              <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                            @enderror
                            
                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="{{ route('partner.partnerlist') }}"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
@include('lowerpart')