@include('upperpart')

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">API Key</li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>API Key </h2>
                    </div>
                    <div class="body">
                        <div class="add-button text-right">
                            <a href="{{ route('apikey.add') }}"><button type="button" class="btn btn-raised btn-primary waves-effect">Add API Key</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>API Name</th>
                                        <th>IP</th>
                                        <th>Secret ID</th>
                                        <th>Secret Key</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
								
                                <tbody>
                                    @foreach($apikey_result as $key => $apikey)
                                    <tr>
                                        <td>{{ $apikey->api_name }}</td>
                                        <td>{{ $apikey->ip_add }}</td>
                                        <td>{{ $apikey->secret_id }}</td>
                                        <td>{{ $apikey->secret_key }}</td>
                                        <td>{{ $apikey->status == 1 ? 'Active' : 'Inactive' }}</td>
                                        <td>{{ date('d-m-Y', strtotime($apikey->created_at)) }}</td>
                                        <td><a href="{{ url('edit_apikey').'/'.$apikey->api_key_id }}"><div class="demo-google-material-icon"> <i class="material-icons" title="Edit">edit</i></div></a></td>
                                    </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@include('lowerpart')