@include('upperpart')

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">API List</li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>API List </h2>
                    </div>
                    <div class="body">
                        <div class="add-button text-right">
                            <a href="{{ route('apikey.addapi') }}"><button type="button" class="btn btn-raised btn-primary waves-effect">Add API</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>API Name</th>
                                        <th>API URL</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
								
                                <tbody>
                                    @foreach($api_result as $key => $api)
                                    <tr>
                                        <td>{{ $api['api_name'] }}</td>
                                        <td>{{ $api['api_url'] }}</td>
                                        <td>{{ $api['status'] == 1 ? 'Active' : 'Inactive' }}</td>
                                        <td>{{ date('d-m-Y', strtotime($api['created_at'])) }}</td>
                                        <td><a href="{{ url('edit_api').'/'.$api['api_id'] }}"><div class="demo-google-material-icon"> <i class="material-icons" title="Edit">edit</i></div></a></td>
                                    </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@include('lowerpart')