<!DOCTYPE html>
<html>

@include('include/header')

<body class="theme-red">
    <!-- Page Loader -->
    @include('include/loader')

    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>

    <!-- #Float icon -->
    @include('include/floaticon')

    <!-- Search  -->
    @include('include/search-bar')

    <!-- Top Bar -->
    @include('include/navbar')

   @include('include/leftsidebar')

   @include('include/rightsidebar')