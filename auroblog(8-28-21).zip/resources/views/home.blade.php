@include('upperpart')

    <section class="content">
        lorem ipsum
    </section>
@include('lowerpart')