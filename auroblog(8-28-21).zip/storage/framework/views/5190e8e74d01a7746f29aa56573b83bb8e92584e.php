<?php echo $__env->make('upperpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">API List</li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(session('message')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('message')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('error')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>API List </h2>
                    </div>
                    <div class="body">
                        <div class="add-button text-right">
                            <a href="<?php echo e(route('apikey.addapi')); ?>"><button type="button" class="btn btn-raised btn-primary waves-effect">Add API</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>API Name</th>
                                        <th>API URL</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
								
                                <tbody>
                                    <?php $__currentLoopData = $api_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($api['api_name']); ?></td>
                                        <td><?php echo e($api['api_url']); ?></td>
                                        <td><?php echo e($api['status'] == 1 ? 'Active' : 'Inactive'); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($api['created_at']))); ?></td>
                                        <td><a href="<?php echo e(url('edit_api').'/'.$api['api_id']); ?>"><div class="demo-google-material-icon"> <i class="material-icons" title="Edit">edit</i></div></a></td>
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('lowerpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/apikey/apilist.blade.php ENDPATH**/ ?>