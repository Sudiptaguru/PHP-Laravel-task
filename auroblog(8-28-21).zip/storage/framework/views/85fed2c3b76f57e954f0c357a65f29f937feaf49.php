<?php echo $__env->make('upperpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="">Partner </a></li>
                        <li class="breadcrumb-item active">Add Partner </li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(session('message')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('message')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <?php if(session('errormsg')): ?>
         <div class="row clearfix">
            <div class="col-sm-12">
              <div class="">
                <?php $__errorArgs = ['partner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['partner_internal_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['partner_website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['partner_source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['registration_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['required_params'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          </div>
        <?php endif; ?>
                                                  
        
        
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>Add PARTNER </h2>
                    </div>
                    <div class="body">
                        <form id="form_validation" action="<?php echo e(route('partner.savepartner')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Name</b> </p>
                                    <input type="text" class="form-control" name="partner_name">
                            </div>
                           
                            <div class="form-group">
                                <p class="m-t-10"> <b>Required Params</b> </p>
                                    <input type="text" class="form-control" name="required_params">
                            </div>
                            <div class="form-group">
                                <p class="m-t-10"> <b>Registration Date</b> </p>
                                    <input type="text" name="date" class="datepicker form-control" autocomplete="off">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Internal URL</b> </p>
                                    <input type="text" class="form-control" name="partner_internal_url">
                            </div>
                           
                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Source</b> </p>
                                    <input type="text" class="form-control" name="partner_source">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Logo</b> </p>
                                    <input type="text" class="form-control" name="partner_logo">
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>Partner Website</b> </p>
                                    <input type="text" class="form-control" name="partner_website">
                            </div>
                            
                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="<?php echo e(route('apikey.apilist')); ?>"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
<?php echo $__env->make('lowerpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/partner/addpartner.blade.php ENDPATH**/ ?>