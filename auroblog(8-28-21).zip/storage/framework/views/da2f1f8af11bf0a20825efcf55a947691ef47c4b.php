<?php echo $__env->make('upperpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="content">   
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                        <li class="breadcrumb-item active">Partner List</li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if(session('message')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('message')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('error')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>Partner List </h2>
                    </div>
                    <div class="body">
                        <div class="add-button text-right">
                            <a href="<?php echo e(route('partner.addpartner')); ?>"><button type="button" class="btn btn-raised btn-primary waves-effect">Add Partner</button></a>
                        </div>    
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>Partner Name</th>
                                        <th>Partner Logo</th>
                                        <th>Partner Website</th>
                                        <th>Partner Internal URL</th>
                                        <th>Required Params</th>
                                        <th>Partner Source</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php $__currentLoopData = $result['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($partner['partner_name']); ?></td>
                                        <td><?php echo e($partner['partner_logo']); ?></td>
                                        <td><?php echo e($partner['partner_website']); ?></td>
                                        <td><?php echo e($partner['partner_internal_url']); ?></td>
                                        <td><?php echo e($partner['required_params']); ?></td>
                                        <td><?php echo e($partner['partner_source']); ?></td>
                                        <td><a class="demo-google-material-icon" href="<?php echo e(url('edit_partner').'/'.$partner['partner_id']); ?>"><i class="material-icons" title="Edit">edit</i></a>|
                                            <a class="demo-google-material-icon" href="<?php echo e(url('delete_partner').'/'.$partner['partner_id']); ?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fa fa-trash-o" style="font-size:24px"></i></a>
                                        </td>
                                    </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('lowerpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/partner/partnerlist.blade.php ENDPATH**/ ?>