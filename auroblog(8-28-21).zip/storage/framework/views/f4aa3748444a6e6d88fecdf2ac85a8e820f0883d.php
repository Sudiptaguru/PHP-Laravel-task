

<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('apikey.apilist')); ?> ">API </a></li>
                        <li class="breadcrumb-item active">Edit API</li>
                    </ul>
                </div>
            </div>
        </div>
        <?php if(session('message')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('message')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center"><?php echo e(session('error')); ?></span>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="row clearfix">
            <div class="col-lg-12 class="card">
                    <div class="header">
                        <h2>Edit API </h2>
                    </div>
                    <div class="body">
                        <form id="form_validation" action="<?php echo e(route('apikey.updateapi')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
							
                            <input type="hidden" id="api_id" name="api_id" value="<?php echo e(@$api_result->api_id); ?>" />
                            <div class="form-group">
                                <p class="m-t-10"> <b>API Name</b> </p>
                                    <input type="text" class="form-control" name="api_name"  value="<?php echo e($api_result->api_name); ?>" required>
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>API URL</b> </p>
                                    <input type="text" class="form-control" name="api_url"  value="<?php echo e($api_result->api_url); ?>" required>
                            </div>
							
                            <div class="form-group">
                                <p class="m-t-10"> <b>Status</b> </p>
                                <select class="form-control show-tick" name="status"  required id="status">
                                    <option value="">-- Select Status --</option>
                                    <option value="1" <?php echo e($api_result->status == 1 ? 'selected="selected"' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e($api_result->status == 0 ? 'selected="selected"' : ''); ?>>Inactive</option>
                                </select>
                            </div>

                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="<?php echo e(route('apikey.apilist')); ?>"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.advanced_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/apikey/editapi.blade.php ENDPATH**/ ?>