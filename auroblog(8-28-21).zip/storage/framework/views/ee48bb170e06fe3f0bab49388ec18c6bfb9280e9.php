<!-- Jquery Core Js --> 

<script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script> <!-- Lib Scripts Plugin Js --> 
<script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script> <!-- Lib Scripts Plugin Js --> 

<!-- Jquery DataTable Plugin Js --> 
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script> <!-- Lib Scripts Plugin Js --> 

<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script><!-- Custom Js --> 
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
$(function() {
   function formatDate(d) {
     var day = String(d.getDate())
     //add leading zero if day is is single digit

     if (day.length == 1)
       day = '0' + day
     var month = String((d.getMonth()+1))
     //add leading zero if month is is single digit
     if (month.length == 1)
       month = '0' + month
     return d.getFullYear() + '-' + month + "-" + day;
   }

   $('.datepicker').datepicker({
        format: 'mm/dd/yyyy',
         beforeShowDay: function(date){
          var dayNr = date.getDay();
            if (dayNr==0  ||  dayNr==6){
               
            }
            
        }
   });
});
</script><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/include/footerjs.blade.php ENDPATH**/ ?>