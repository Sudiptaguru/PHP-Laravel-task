<?php
namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ApiKey;
use App\Models\ApiMaster;
use App\Models\ApiKeyMaster;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

require (__DIR__.'/../../helper.php');

class ApiKeyController extends Controller{

    /**
     * Create a new controller instance.
     * Kohin Maji     * @return void
     */
    public function __construct(){
        //$this->middleware('auth');
    }

    /**
     * Show the listing.
     * Kohin Maji
     * 27-07-2021
     * @return \Illuminate\View\View
     */
    public function index(Request $request){
		$apikey_result =DB::table('api_key_master')->select('api_key_id', 'api_key_master.api_id', 'api_master.api_name', 'ip_add', 'secret_id', 'secret_key', 'api_key_master.status', 'api_key_master.created_at')->join('api_master','api_key_master.api_id','=','api_master.api_id')->get();
        return view('apikey.list',compact('apikey_result'));
    }

    /**
     * Show the form for creating a new resource.
     * Kohin Maji
     * 27-07-2021
     * @return \Illuminate\Http\Response
     */
    public function add(){
        //$api_result = ApiMaster::get(array('api_id', 'api_name'))->toArray();
		$api_result = DB::table('api_master')->get();
        //return view('apikey.add');
        return view('apikey.add',compact('api_result'));
		//return view('apikey.add',['api_result'=>$api_result]);
    }

    /**
     * Show the form for editing the specified resource.
     * Kohin Maji
     * 27-07-2021
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
        $apikey_result = ApiKeyMaster::where('api_key_id', $id)->get(array('api_key_id', 'api_id', 'ip_add', 'secret_id', 'secret_key', 'status'))->first();        
        if(!empty($apikey_result->api_key_id)){
			$api_result = DB::table('api_master')->get();	
            return view('apikey.edit',compact('apikey_result', 'api_result'));
        }else{
            return redirect()->route('apikey.list')->with('error','Sorry no result found');    
        }         
    }

    /**
     * Save the specified resource.
     * Kohin Maji
     * 27-07-2021
     * @param  
     * @return \Illuminate\Http\Response
     */

    public function save(Request $request){
        $post_data = $request->toArray();

        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->id)){ // redirect if already exist
            return redirect()->route('apikey.add')->with('error','API Key Combination already exist');
        }
        $apikey_master = [];
        $apikey_master['api_id'] = $post_data['api_id'];
        $apikey_master['ip_add'] = $post_data['ip_add'];
        $apikey_master['secret_id'] = sha1(uniqid());
        $apikey_master['secret_key'] = hash("sha256", uniqid());;

        $apikey_master['created_at'] = date('Y-m-d H:i:s');
        $apikey_master['updated_at'] = date('Y-m-d H:i:s');

        ApiKeyMaster::create($apikey_master);
        return redirect()->route('apikey.list')->with('message','API Key added succesfully');
    }

    /**
     * Update the specified resource.
     * Kohin Maji
     * 27-07-2021
	 * @param  
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request){
        $post_data = $request->toArray();
        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->api_key_id)){ // redirect if already exist
            return redirect()->route('apikey.edit',$post_data['api_key_id'])->with('error','API Key Combination already exist');
        }
        $apikey_master = [];
        $apikey_master['api_id'] = $post_data['api_id'];
        $apikey_master['ip_add'] = $post_data['ip_add'];
        $apikey_master['status'] = $post_data['status'];
        $apikey_master['updated_at'] = date('Y-m-d H:i:s');

        ApiKeyMaster::where('api_key_id',$post_data['api_key_id'])->update($apikey_master);
        return redirect()->route('apikey.list')->with('message','API Key updated succesfully');
    }
	
	public function apilist(Request $request){
		//$api_result = ApiMaster::get(array('api_id', 'api_name', 'api_url', 'status', 'created_at'))->toArray();
		
		
		$set_limit=10;
		$set_page=1;

		$filePath =  array("set_limit" => $set_limit, "set_page" => $set_page);
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "https://staging.auroscholar.org/apis/apimod/apilist.php",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30000,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => json_encode($filePath),
		CURLOPT_HTTPHEADER => array(
		// Set here requred headers
		"content-type: application/json",
		"Secret-Id: 2198f0011288666d3694ccf4e7d16c29",
		"Secret-Key: f7115915ae4efc1bdab7ae9fc686348848f8cc2e7bf4a9",
		"Lang-Code: english"
		),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if($err){
			echo "cURL Error #:" . $err;
		}
		else{
			$result = json_decode($response, true);
			$api_result=$result['data'];
			//print_r($api_result);			
		}	
		
		
        return view('apikey.apilist',compact('api_result'));
    }
	
    public function addapi(){
        return view('apikey.addapi');
    }

    public function editapi($id){
        $api_result = ApiMaster::where('api_id', $id)->get(array('api_id', 'api_name', 'api_url', 'status'))->first();        
        if(!empty($api_result->api_id)){
            return view('apikey.editapi',compact('api_result'));
        }else{
            return redirect()->route('apikey.apilist')
             ->with('error','Sorry no result found');    
        }        
    }

    public function saveapi(Request $request){
        $post_data = $request->toArray();

        //$login_user_id = auth()->user()['id'];

        if(!empty($check_exist_result->api_id)){ // redirect if already exist
            return redirect()->route('apikey.addapi')
             ->with('error','API Combination already exist');
        }
        $api_master = [];
        $api_master['api_name'] = $post_data['api_name'];
        $api_master['api_url'] = $post_data['api_url'];

        $api_master['created_at'] = date('Y-m-d H:i:s');
        $api_master['updated_at'] = date('Y-m-d H:i:s');

        ApiMaster::create($api_master);

        return redirect()->route('apikey.apilist')->with('message','API added succesfully');
    }
	
    public function updateapi(Request $request){
        $post_data = $request->toArray();
        //$login_user_id = auth()->user()['id'];
        if(!empty($check_exist_result->api_id)){ // redirect if already exist
            return redirect()->route('apikey.editapi',$post_data['api_id'])->with('error','API Combination already exist');
        }

        $api_master = [];
        $api_master['api_name'] = $post_data['api_name'];
        $api_master['api_url'] = $post_data['api_url'];
        $api_master['status'] = $post_data['status'];
        $api_master['updated_at'] = date('Y-m-d H:i:s');

        ApiMaster::where('api_id',$post_data['api_id'])->update($api_master);
        return redirect()->route('apikey.apilist')->with('message','API updated succesfully');
    }
}