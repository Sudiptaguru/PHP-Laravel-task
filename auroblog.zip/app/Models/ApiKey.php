<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class ApiKey extends Model
{
    protected $connection = 'mysql';

    protected $table = "api_key";
    
    protected $fillable = [
        'id', 'user_id', 'api', 'api_url', 'ip_add', 'secret_id', 'secret_key', 'status', 'created_by', 'updated_by', 'created_at', 'updated_at'
    ];
}