<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PartnerController;
use App\Http\Controllers\ApiKeyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::view('user','partner_datatable');
Route::get('partner',[PartnerController::class,'index']);

/* API KEY Master */

Route::get('apikey', [ApiKeyController::class, 'index'])->name('apikey.list');

Route::get('add_apikey', [ApiKeyController::class, 'add'])->name('apikey.add');

Route::get('edit_apikey/{id}', [ApiKeyController::class, 'edit'])->name('apikey.edit');

Route::post('save_apikey', [ApiKeyController::class, 'save'])->name('apikey.save');

Route::post('update_apikey', [ApiKeyController::class, 'update'])->name('apikey.update');


Route::get('api', [ApiKeyController::class, 'apilist'])->name('apikey.apilist');

Route::get('add_api', [ApiKeyController::class, 'addapi'])->name('apikey.addapi');

Route::get('edit_api/{id}', [ApiKeyController::class, 'editapi'])->name('apikey.editapi');

Route::post('save_api', [ApiKeyController::class, 'saveapi'])->name('apikey.saveapi');

Route::post('update_api', [ApiKeyController::class, 'updateapi'])->name('apikey.updateapi');
