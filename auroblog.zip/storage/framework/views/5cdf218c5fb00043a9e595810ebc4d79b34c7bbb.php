<?php echo $__env->make('upperpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="content">
        lorem ipsum
    </section>
<?php echo $__env->make('lowerpart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/home.blade.php ENDPATH**/ ?>