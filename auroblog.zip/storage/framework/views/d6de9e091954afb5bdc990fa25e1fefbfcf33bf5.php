<?php echo $__env->make('include/footerjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp1\htdocs\Techno_Brains\auroblog\resources\views/lowerpart.blade.php ENDPATH**/ ?>