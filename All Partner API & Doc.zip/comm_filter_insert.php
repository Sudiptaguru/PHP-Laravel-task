<?php
//********* [BASEURL]/partner/comm_filter_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_com_id"]) || $data["partner_com_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.60"];
				}
				elseif (!isset($data["filter_name"]) || $data["filter_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.68"];
				}
				elseif (!isset($data["status"]) || $data["status"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.69"];
				}
				else {
					$partner_com_id 		= filter_var(trim($data["partner_com_id"]), FILTER_SANITIZE_NUMBER_INT);
					$filter_name			= filter_var(trim($data["filter_name"]), FILTER_SANITIZE_STRING);
					$filter_data_type 		= filter_var(trim($data["filter_data_type"]), FILTER_SANITIZE_STRING);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$created_by 			= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					
					$stmt = $con->prepare("SELECT * FROM partner_com_master WHERE partner_com_id = '".$partner_com_id."'");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows < 1) {
						$return["response_code"]	= 400;	
						$return["message"]			= $AuroLangConvert["400.57"];
					}
					else {
						$row = $result->fetch_assoc();
						$partner_id = $row['partner_id'];

						$stmt = $con->prepare("SELECT * FROM partner_filter_master WHERE partner_com_id = '".$partner_com_id."' ORDER BY partner_filter_master DESC LIMIT 1");
						$stmt->execute();
						$result = $stmt->get_result();
						$field_value_sequence = 1;
						if($result->num_rows > 0) {
							$row_filter = $result->fetch_assoc();
							$field_value_sequence = $row_filter['field_value_sequence'] + 1;
						}

						$current_date = date('Y-m-d H:i:s');
						$stmt = $con->prepare("INSERT INTO partner_filter_master (`partner_com_id`, `filter_name`, `filter_data_type`, `status`, `field_value_sequence`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES ('".$partner_com_id."', '".$filter_name."', '".$filter_data_type."', '".$status."', '".$field_value_sequence."','".$created_by."', '".$updated_by."', '".$current_date."','".$current_date."' )");
						$stmt->execute();
						$record_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["partner_filter_master"]	= (string)$record_id;
						$return["data"]["partner_com_id"]	= (string)$partner_com_id;
						$return["data"]["partner_id"]		= (string)$partner_id;
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>