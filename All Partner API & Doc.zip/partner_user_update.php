<?php
//********* [BASEURL]/partner/partner_user_update.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_user_id"]) || $data["partner_user_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.58"];
				}
				elseif (!isset($data["partner_id"]) || $data["partner_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.54"];
				}
				elseif (!isset($data["user_type_id"]) || $data["user_type_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.53"];
				}
				elseif (!isset($data["user_name"]) || $data["user_name"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.3"];
				}
				elseif (!isset($data["role_id"]) || $data["role_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.52"];
				}
				else {
					$partner_user_id 	= filter_var(trim($data["partner_user_id"]), FILTER_SANITIZE_NUMBER_INT);
					$user_name 			= filter_var(trim($data["user_name"]), FILTER_SANITIZE_STRING);
					$partner_id			= filter_var(trim($data["partner_id"]), FILTER_SANITIZE_NUMBER_INT);
					$user_type_id 		= filter_var(trim($data["user_type_id"]), FILTER_SANITIZE_NUMBER_INT);
					$password 			= filter_var(trim($data["password"]), FILTER_SANITIZE_STRING);
					$role_id 			= filter_var(trim($data["role_id"]), FILTER_SANITIZE_NUMBER_INT);
					$status 			= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 		= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					$created_at 		= date('Y-m-d H:i:s');

					$stmt = $con->prepare("SELECT * FROM partner_user_mapping LEFT join user_master ON partner_user_mapping.user_id=user_master.user_id where partner_user_mapping.partner_user_id='".$partner_user_id."' AND partner_user_mapping.partner_id='".$partner_id."'");
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows === 0) {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.57"];
					}
					else {
						$row 			= $result->fetch_assoc();
						$user_id 		= $row['user_id'];
						$current_date 	= date('Y-m-d H:i:s');
						$stmt = $con->prepare("UPDATE user_master SET user_name = '".$user_name."', password = '".$password."', user_type_id = '".$user_type_id."', status = '".$status."', role_id = '".$role_id."', updated_by = '".$updated_by."', updated_at = '".$current_date."' WHERE user_id=".$user_id);
						$stmt->execute();
						$stmt = $con->prepare("UPDATE partner_user_mapping SET partner_id = '".$partner_id."', updated_by = '".$updated_by."', updated_at = '".$current_date."' WHERE partner_user_id=".$partner_user_id);
						$stmt->execute();

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.3"];
						$return["data"]["partner_id"]		= (string)$partner_id;
						$r = [];
						foreach($row as $key => $val) {
							$r[$key] = (string)$val;
						}
						$return["data"] = $r;
						unset($return["data"]["password"]);
					}
					$stmt->close();
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>