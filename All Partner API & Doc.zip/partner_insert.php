<?php
//********* [BASEURL]/api/partner/partner_insert.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_name"]) || $data["partner_name"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.51"];
				}
				elseif (!isset($data["role_id"]) || $data["role_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.52"];
				}
				elseif (!isset($data["user_type_id"]) || $data["user_type_id"] == '' ){
					$return["response_code"]	= 400;	
					$return["message"]			= $AuroLangConvert["400.53"];
				}
				else {
					$partner_name 			= filter_var(trim($data["partner_name"]), FILTER_SANITIZE_STRING);
					$partner_source 		= filter_var(trim($data["partner_source"]), FILTER_SANITIZE_STRING);
					$registration_date 		= filter_var(trim($data["registration_date"]), FILTER_SANITIZE_STRING);
					$feature 				= filter_var(trim($data["feature"]), FILTER_SANITIZE_NUMBER_INT);
					$user_type_id 			= filter_var(trim($data["user_type_id"]), FILTER_SANITIZE_NUMBER_INT);
					$role_id 				= filter_var(trim($data["role_id"]), FILTER_SANITIZE_NUMBER_INT);
					$status 				= filter_var(trim($data["status"]), FILTER_SANITIZE_NUMBER_INT);
					$partner_logo 			= filter_var(trim($data["partner_logo"]), FILTER_SANITIZE_STRING);
					$partner_website 		= filter_var(trim($data["partner_website"]), FILTER_SANITIZE_STRING);
					$partner_internal_url 	= filter_var(trim($data["partner_internal_url"]), FILTER_SANITIZE_STRING);
					$required_params 		= filter_var(trim($data["required_params"]), FILTER_SANITIZE_STRING);
					$mobile_no_verified 	= filter_var(trim($data["mobile_no_verified"]), FILTER_SANITIZE_NUMBER_INT);
					$created_by 			= filter_var(trim($data["created_by"]), FILTER_SANITIZE_NUMBER_INT);
					$updated_by 			= filter_var(trim($data["updated_by"]), FILTER_SANITIZE_NUMBER_INT);
					$created_at 			= date('Y-m-d H:i:s');

					$newpartner_name = 'admin_partner_'.strtolower(clean_str($partner_name));
					$stmt = $con->prepare("SELECT * FROM user_master where user_name='".$newpartner_name."' and user_type_id='".$user_type_id."'");
					$stmt->execute();
					$result = $stmt->get_result(); 
					if($result->num_rows === 0) {
						$current_date = date('Y-m-d H:i:s');
						$stmt = $con->prepare("INSERT INTO user_master (user_name, password, user_type_id, status, role_id, created_at, created_by,updated_by,updated_at) VALUES ('".$newpartner_name."', '".md5($newpartner_name)."', '".$user_type_id."', '".$status."', '".$role_id."', '".$current_date."', '".$created_by."', '".$updated_by."', '".$current_date."')");
						$stmt->execute();
						$user_id = $stmt->insert_id;
						$stmt = $con->prepare("INSERT INTO auro_partner_master (partner_name, partner_source, registration_date, feature, status, partner_logo, partner_website, partner_internal_url, required_params, mobile_no_verified, created_by, updated_by, created_at, updated_at) VALUES ('".$partner_name."', '".$partner_source."', '".$registration_date."','".$feature."','".$status."','".$partner_logo."','".$partner_website."','".$partner_internal_url."','".$required_params."','".$mobile_no_verified."','".$created_by."','".$updated_by."','".$created_at."','".$current_date."')");
						$stmt->execute();
						$partner_id = $stmt->insert_id;

						$stmt = $con->prepare("INSERT INTO partner_user_mapping (partner_id, user_id, created_by, updated_by, created_at, updated_at) VALUES ('".$partner_id."', '".$user_id."', '".$created_by."','".$updated_by."','".$created_at."','".$current_date."')");
						$stmt->execute();
						$partner_user_id = $stmt->insert_id;

						$return["status"]					= "success";
						$return["error"]					= "false";
						$return["response_code"]			= 200;			
						$return["message"]					= $AuroLangConvert["200.1"];
						$return["data"]["user_id"]			= (string)$user_id;
						$return["data"]["partner_id"]		= (string)$partner_id;
						$return["data"]["partner_user_id"]	= (string)$partner_user_id;
					}
					else {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.50"];
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>