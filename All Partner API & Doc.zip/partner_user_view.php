<?php
//********* [BASEURL]/partner/partner_user_view.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["partner_user_id"]) || $data["partner_user_id"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.58"];
				}
				else {
					$partner_user_id 	= filter_var(trim($data["partner_user_id"]), FILTER_SANITIZE_NUMBER_INT);
					$stmt = $con->prepare("SELECT * FROM partner_user_mapping LEFT join user_master ON partner_user_mapping.user_id=user_master.user_id where partner_user_mapping.partner_user_id='".$partner_user_id."'");
					$stmt->execute();
					$result = $stmt->get_result(); 
					if($result->num_rows === 0) {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.11"];
					}
					else {
						$row = $result->fetch_assoc();
						$return["status"]		= "success";
						$return["error"]		= "false";
						$return["response_code"]= 200;
						$return["message"]		= $AuroLangConvert["200.4"];
						$r = [];
						foreach($row as $key => $val) {
							$r[$key] = (string)$val;
						}
						$return["data"] = $r;
						unset($return["data"]["password"]);
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>