<?php
//********* [BASEURL]/api/partner/partner_list.php ********/

ob_start();
include("../db.php");
include("../functions.php");
$headers = apache_request_headers();
$return = array();
$return["status"] 	= "fail";
$return["error"] 	= "true";
$collection=array();
$server_ip=$_SERVER["SERVER_ADDR"];
$lang_code =  strtolower($headers["Lang-Code"]);
$allowedMethods = array('POST');
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD']);
if(!in_array($requestMethod, $allowedMethods)){	
	http_response_code(405);
	$return["response_code"]=405;
	$return["message"]=$AuroLangConvert["405.1"];
	echo json_encode($return,JSON_UNESCAPED_UNICODE);
	exit;			
}
if($lang_code!=""){
	if(file_get_contents("../".$lang_code.".php")){
		include("../".$lang_code.".php");
	}
	else{
		include("../english.php");		
	}
}
else{
	include("../english.php");
}
if(isset($headers["Secret-Id"]) && isset($headers["Secret-Key"]) && isset($headers["Lang-Code"])){
	$secretid =  $headers["Secret-Id"];
	$secretkey =  $headers["Secret-Key"];
	
	if(CheckAuthentication($secretid, $secretkey, $server_ip)) {
		$json = file_get_contents('php://input');
		if(trim($json)=="") {
			$return["response_code"]	= 400;			
			$return["message"]			= $AuroLangConvert["400.1"];			
		}
		else {
			$data = json_decode($json,true);
			if(!empty($data)) {
				if (!isset($data["set_limit"]) || $data["set_limit"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.55"];
				}
				elseif (!isset($data["set_page"]) || $data["set_page"] == '' ){
					$return["response_code"]	= 400;			
					$return["message"]			= $AuroLangConvert["400.56"];
				}
				else {
					$set_limit 	= filter_var(trim($data["set_limit"]), FILTER_SANITIZE_NUMBER_INT);
					$set_page 	= filter_var(trim($data["set_page"]), FILTER_SANITIZE_NUMBER_INT);
					$offset 	= 0;
					$newLimit 	= 30;
					if($set_limit and $set_page){
						$offset = ($set_page - 1) * $set_limit;
						$newLimit = ($set_page * $set_limit);
					}
					$sql_raw = "SELECT SQL_CALC_FOUND_ROWS apm.partner_id,apm.partner_name,apm.partner_source,apm.registration_date,apm.feature,apm.status,apm.partner_logo,apm.partner_website,apm.partner_internal_url,apm.required_params,apm.mobile_no_verified,pum.partner_user_id,um.user_id,um.user_name,um.role_id FROM auro_partner_master apm LEFT join partner_user_mapping pum ON pum.partner_id=apm.partner_id LEFT JOIN user_master um ON um.user_id =pum.user_id ORDER BY apm.partner_id DESC LIMIT ".$offset.",".$newLimit;
					$stmt = $con->prepare($sql_raw);
					$stmt->execute();
					$result = $stmt->get_result();
					if($result->num_rows === 0) {
						$return["response_code"]= 400;			
						$return["message"]=$AuroLangConvert["400.11"];
					}
					else {
						$return["status"]		= "success";
						$return["error"]		= "false";
						$return["response_code"]= 200;
						$return["message"]		= $AuroLangConvert["200.4"];
						while ($row = $result->fetch_assoc()) {
							$r = [];
							foreach($row as $key => $val) {
								$r[$key] = (string)$val;
							}
							$return["data"][] 	= $r;
				        }
				        $result->free();
				        $stmt = $con->prepare("SELECT FOUND_ROWS() as totalRows");
						$stmt->execute();
						$foundRows = $stmt->get_result();
				        $foundRowsn = $foundRows->fetch_assoc();
				        $return["total_rows"]	= (string)$foundRowsn['totalRows'];
					}
					$stmt->close();	
				}
			}
			else {
				$return["response_code"]	= 400;
				$return["message"]			= $AuroLangConvert["400.1"];
			}			
		}
	}
	else {
		$return["response_code"]	= 403;	
		$return["message"]			= $AuroLangConvert["403.1"];
	}
}
else{
	$return["response_code"]	= 403;	
	$return["message"]			= $AuroLangConvert["403.1"];	
}
echo json_encode($return,JSON_UNESCAPED_UNICODE);
?>