@extends('layouts.advanced_form')

@section('content')

<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('apikey.apilist') }} ">API </a></li>
                        <li class="breadcrumb-item active">Edit API</li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif

        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
        <div class="row clearfix">
            <div class="col-lg-12 class="card">
                    <div class="header">
                        <h2>Edit API </h2>
                    </div>
                    <div class="body">
                        <form id="form_validation" action="{{ route('apikey.updateapi') }}" method="POST">
                            @csrf
							
                            <input type="hidden" id="api_id" name="api_id" value="{{ @$api_result->api_id }}" />
                            <div class="form-group">
                                <p class="m-t-10"> <b>API Name</b> </p>
                                    <input type="text" class="form-control" name="api_name"  value="{{ $api_result->api_name }}" required>
                            </div>

                            <div class="form-group">
                                <p class="m-t-10"> <b>API URL</b> </p>
                                    <input type="text" class="form-control" name="api_url"  value="{{ $api_result->api_url }}" required>
                            </div>
							
                            <div class="form-group">
                                <p class="m-t-10"> <b>Status</b> </p>
                                <select class="form-control show-tick" name="status"  required id="status">
                                    <option value="">-- Select Status --</option>
                                    <option value="1" {{ $api_result->status == 1 ? 'selected="selected"' : '' }}>Active</option>
                                    <option value="0" {{ $api_result->status == 0 ? 'selected="selected"' : '' }}>Inactive</option>
                                </select>
                            </div>

                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="{{ route('apikey.apilist') }}"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection