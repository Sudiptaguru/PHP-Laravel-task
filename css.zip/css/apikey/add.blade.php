@extends('layouts.advanced_form')
@section('content')
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <div class="row">
                <div class="col-lg-12 col-md-6 col-sm-7">
                    <ul class="breadcrumb">                        
                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('apikey.list') }} ">API Key</a></li>
                        <li class="breadcrumb-item active">Add API Key</li>
                    </ul>
                </div>
            </div>
        </div>
        @if (session('message'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('message') }}</span>
              </div>
            </div>
          </div>
        @endif
                                                  
        @if (session('error'))
          <div class="row clearfix">
            <div class="col-sm-12">
              <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <span class="text-center">{{ session('error') }}</span>
              </div>
            </div>
          </div>
        @endif
		
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card">
                    <div class="header">
                        <h2>Add API Key</h2>
                    </div>
                    <div class="body">
                        <form id="form_validation" action="{{ route('apikey.save') }}" method="POST">
                            @csrf
							  <div class="form-group">
								<label for="api_id">Api Name</label>
								<select class="form-control show-tick" id="api_id" name="api_id">
								  <option value="">Select Api Name</option>
								   @foreach ($api_result as $key => $apis)
									<option value="{{$apis->api_id}}">{{$apis->api_name}}</option>
                                   @endforeach 
								</select>
							  </div>							
							
							  <div class="form-group">
								<label for="ip_add">IP Address</label>
								<input type="text" class="form-control" id="ip_add" name="ip_add" placeholder="Enter IP Address">
							  </div>							
							
                            <button class="btn btn-raised btn-primary waves-effect" type="submit">Save</button>
                            <a href="{{ route('apikey.list') }}"><button class="btn btn-raised btn-primary waves-effect" type="button">Cancel</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
@endsection