<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NewActivityMasterController;
use App\Http\Controllers\SubActivityMasterController;
use App\Http\Controllers\BucketMasterController;
use App\Http\Controllers\QuestionMasterController;
use App\Http\Controllers\ApiKeyController;
use App\Http\Controllers\CustomSqlController;
use App\Http\Controllers\CommunicationMasterController;
use App\Http\Controllers\Cron\InternalController;
use App\Http\Controllers\Cron\AwsController;
use App\Http\Controllers\Cron\ZipController;


use App\Http\Controllers\DonorController;
use App\Http\Controllers\RazorpayController;
use App\Http\Controllers\TeacherController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* 
|--------------------------------------------------------------------------
| User View Routes
|-------------------------------------------------------------------------- 
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('move_to_aws', [AwsController::class, 'move_to_aws'])->name('move_to_aws');

Route::get('folder_to_zip', [ZipController::class, 'folder_to_zip'])->name('folder_to_zip');

Route::get('insert_to_test', [InternalController::class, 'insert_to_test'])->name('insert_to_test');

Route::get('insert_to_bucket', [InternalController::class, 'insert_to_bucket'])->name('insert_to_bucket');

Route::get('insert_to_question', [InternalController::class, 'insert_to_question'])->name('insert_to_question');

Route::get('get_test_data', [InternalController::class, 'get_test_data'])->name('get_test_data');

/* Activity Master */

Route::get('get_activities', [NewActivityMasterController::class, 'index'])->name('new_activity.list');

Route::get('add_activity', [NewActivityMasterController::class, 'add'])->name('new_activity.add');

Route::get('edit_activity/{id}', [NewActivityMasterController::class, 'edit'])->name('new_activity.edit');

Route::post('save_activity', [NewActivityMasterController::class, 'save'])->name('new_activity.save');

Route::post('update_activity', [NewActivityMasterController::class, 'update'])->name('new_activity.update');

/* End Activity Master */


/* Sub Activity Master */

Route::get('get_sub_activities', [SubActivityMasterController::class, 'index'])->name('sub_activity.list');

Route::get('get_new_sub_activities', [SubActivityMasterController::class, 'get_new_sub_activities'])->name('sub_activity.get_new_sub_activities');

Route::get('set_sub_activity', [SubActivityMasterController::class, 'set_sub_activities'])->name('sub_activity.set_sub_activity');

Route::get('edit_new_sub_activity/{id}', [SubActivityMasterController::class, 'edit_new_sub_activity'])->name('sub_activity.edit_new_sub_activity');

Route::get('add_sub_activity', [SubActivityMasterController::class, 'add'])->name('sub_activity.add');

Route::get('edit_sub_activity/{id}', [SubActivityMasterController::class, 'edit'])->name('sub_activity.edit');

Route::post('save_sub_activity', [SubActivityMasterController::class, 'save'])->name('sub_activity.save');

Route::post('save_new_sub_activity', [SubActivityMasterController::class, 'save_new_sub_activity'])->name('sub_activity.save_new_sub_activity');

Route::post('update_new_sub_activity', [SubActivityMasterController::class, 'update_new_sub_activity'])->name('sub_activity.update_new_sub_activity');

Route::post('update_sub_activity', [SubActivityMasterController::class, 'update'])->name('sub_activity.update');

/* End Sub Activity Master */

/* Bucket Master */

Route::get('get_buckets', [BucketMasterController::class, 'index'])->name('bucket.list');

Route::get('add_bucket', [BucketMasterController::class, 'add'])->name('bucket.add');

Route::get('edit_bucket/{id}', [BucketMasterController::class, 'edit'])->name('bucket.edit');

Route::post('save_bucket', [BucketMasterController::class, 'save'])->name('bucket.save');

Route::post('update_bucket', [BucketMasterController::class, 'update'])->name('bucket.update');

/* End Bucket Master */

/* Question Master */

Route::get('questions', [QuestionMasterController::class, 'index'])->name('question.list');

Route::get('add_question', [QuestionMasterController::class, 'add'])->name('question.add');

Route::get('edit_question/{id}', [QuestionMasterController::class, 'edit'])->name('question.edit');

Route::post('save_question', [QuestionMasterController::class, 'save'])->name('question.save');

Route::post('update_question', [QuestionMasterController::class, 'update'])->name('question.update');

/* End Question Master */
/* API KEY Master */

Route::get('apikey', [ApiKeyController::class, 'index'])->name('apikey.list');

Route::get('add_apikey', [ApiKeyController::class, 'add'])->name('apikey.add');

Route::get('edit_apikey/{id}', [ApiKeyController::class, 'edit'])->name('apikey.edit');

Route::post('save_apikey', [ApiKeyController::class, 'save'])->name('apikey.save');

Route::post('update_apikey', [ApiKeyController::class, 'update'])->name('apikey.update');


Route::get('api', [ApiKeyController::class, 'apilist'])->name('apikey.apilist');

Route::get('add_api', [ApiKeyController::class, 'addapi'])->name('apikey.addapi');

Route::get('edit_api/{id}', [ApiKeyController::class, 'editapi'])->name('apikey.editapi');

Route::post('save_api', [ApiKeyController::class, 'saveapi'])->name('apikey.saveapi');

Route::post('update_api', [ApiKeyController::class, 'updateapi'])->name('apikey.updateapi');

/* End API KEY Master */

/* Custom SQl Master */

Route::get('customsql', [CustomSqlController::class, 'index']);
Route::post('customsql', [CustomSqlController::class, 'save']);

/* End Custom SQl Master */

/* Communcation Master */

Route::get('communication', [CommunicationMasterController::class, 'index'])->name('communication.list');

Route::get('add_communication', [CommunicationMasterController::class, 'add'])->name('communication.add');

Route::get('edit_communication/{id}', [CommunicationMasterController::class, 'edit'])->name('communication.edit');

Route::post('save_communication', [CommunicationMasterController::class, 'save'])->name('communication.save');

Route::post('update_communication', [CommunicationMasterController::class, 'update'])->name('communication.update');

Route::post('get_ajax_sub_activities', [CommunicationMasterController::class, 'get_ajax_sub_activities'])->name('communication.sub_activities');

/* End Activity Master */

// home page route
Route::get('/', [HomeController::class, 'index'])->name('home');
// blog page route
Route::get('/blog', function(){
    return view('user.blog');
})->name('blog');
// faq page route
Route::get('/faq', function(){
    return view('user.faq');
})->name('faq');
// press page route
Route::get('/press', function(){
    return view('user.press');
})->name('press');

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

/* 
|--------------------------------------------------------------------------
| Admin View Routes
|-------------------------------------------------------------------------- 
*/
// dashboard page route
Route::get('/dashboard', function(){
    return view('admin.dashboard');
})->name('admin.dashboard');


// Donor

Route::get('/donor/home', [DonorController::class, 'home']);
Route::post('/donor/home', [DonorController::class, 'adddata']);
Route::post('/donor/login', [DonorController::class, 'login'])->name('donor.login');
Route::get('/donor/start', [DonorController::class, 'start']);
Route::post('/donor/start',[RazorpayController::class, 'Initiate']);
Route::post('/payment-complete', [RazorpayController::class, 'Complete'])->name('Complete');

Route::get('/donor/dashboard', [DonorController::class, 'dashboard']);

Route::get('/teacher/register', [TeacherController::class, 'index']);
Route::post('teacher/register', [TeacherController::class, 'register']);
Route::post('/teacher/login', [TeacherController::class, 'login']);
Route::get('/teacher/dashboard', [TeacherController::class, 'dashboard']);
// Donor End