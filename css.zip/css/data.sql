
--
-- Table structure for table `api_key`
--

CREATE TABLE `api_key` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `api` varchar(255) NOT NULL,
  `api_url` varchar(255) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `secret_id` varchar(255) NOT NULL,
  `secret_key` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0 -> Inactive 1 -> Active',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `api_key_master`
--

CREATE TABLE `api_key_master` (
  `api_key_id` bigint(20) UNSIGNED NOT NULL,
  `api_id` bigint(20) UNSIGNED NOT NULL,
  `ip_add` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0 -> Inactive 1 -> Active 2 ->Disable',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `api_master`
--

CREATE TABLE `api_master` (
  `api_id` bigint(20) UNSIGNED NOT NULL,
  `api_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '0 -> Inactive 1 -> Active',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_key`
--
ALTER TABLE `api_key`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_key_master`
--
ALTER TABLE `api_key_master`
  ADD PRIMARY KEY (`api_key_id`),
  ADD KEY `api_key_master_api_id_foreign` (`api_id`);

--
-- Indexes for table `api_master`
--
ALTER TABLE `api_master`
  ADD PRIMARY KEY (`api_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_key`
--
ALTER TABLE `api_key`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_key_master`
--
ALTER TABLE `api_key_master`
  MODIFY `api_key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_master`
--
ALTER TABLE `api_master`
  MODIFY `api_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `api_key_master`
--
ALTER TABLE `api_key_master`
  ADD CONSTRAINT `api_key_master_api_id_foreign` FOREIGN KEY (`api_id`) REFERENCES `api_master` (`api_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

